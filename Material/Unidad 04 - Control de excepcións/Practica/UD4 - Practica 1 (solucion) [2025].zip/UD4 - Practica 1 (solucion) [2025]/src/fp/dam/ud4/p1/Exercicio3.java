package fp.dam.ud4.p1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercicio3 {

	/**
	 * Método principal da aplicación
	 * 
	 * @param args Argumentos recibidos por consola
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Cantidade de notas a introducir: ");
			int cantidadeNotas = scanner.nextInt();

			if (cantidadeNotas <= 0) {
				throw new IllegalArgumentException("A cantidade de notas debe ser un número positivo.");
			}

			Double[] notas = new Double[cantidadeNotas];
			int i = 0;
			while (!notasCompletadas(notas)) {
				try {
					System.out.print("Introduce a nota #" + (i + 1) + ": ");
					notas[i] = scanner.nextDouble();
	
					if (notas[i] < 0 || notas[i] > 10) {
						throw new IllegalArgumentException("As notas deben estar no rango de 0 a 10.");
					}
					i++;
				}
				catch (IllegalArgumentException e) {
					System.out.println(e.getMessage());
				}
				catch (InputMismatchException e) {
					System.out.println("Debe inserir un valor numérico");
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					scanner.nextLine();
				}
			}

			double media = calcularMedia(notas);
			System.out.println("A media das notas é: " + media);

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());

		} catch (Exception e) {
			System.out.println((e.getMessage() == null) ? "Erro xeral" : e.getMessage());

		} finally {
			System.out.println("Programa rematado.");
			scanner.close();
		}
	}

	/**
	 * Calcula a media das notas recibidas.
	 * 
	 * @param notas	array coas notas recibidas.
	 * @return	media calculada
	 */
	private static double calcularMedia(Double[] notas) {
		double suma = 0;
		for (double nota : notas) {
			suma += nota;
		}
		return suma / notas.length;
	}
	
	/**
	 * Comproba que todas as notas están inseridas, é dicir non hai nulas.
	 * 
	 * @param notas	array coas notas recibidas.
	 * @return true si están inseridas ou falso en caso contrario
	 */
	private static boolean notasCompletadas(Double[] notas) {
		for (Double nota : notas) {
			if (nota == null)
				return false;
		}
		return true;
	}
	

}
