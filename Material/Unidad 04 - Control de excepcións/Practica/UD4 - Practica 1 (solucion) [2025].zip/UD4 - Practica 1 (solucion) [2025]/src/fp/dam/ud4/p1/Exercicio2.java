package fp.dam.ud4.p1;

import java.util.Scanner;

public class Exercicio2 {

	/**
	 * Método principal da aplicación
	 * 
	 * @param args Argumentos recibidos por consola
	 */
	public static void main(String[] args) {
		String[] elementos = { "Elemento 1", "Elemento 2", "Elemento 3", "Elemento 4", "Elemento 5", "Elemento 6" };

		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Introduce a posición a consultar: ");
			int posicion = scanner.nextInt();

			String elemento = consultarElemento(elementos, posicion);
			System.out.print("O elemento consultado é: " + elemento);

		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("Houbo un erro: " + e.getMessage());
		}
		finally {
			scanner.close();
		}
	}

	/**
	 * Consulta a posición indicada dentro dos elementos do array
	 * 
	 * @param  elementos Array cos elementos a consultar
	 * @param  posicion  Posición enteira do array
	 * @return           Elemento consultado
	 */
	public static String consultarElemento(String[] elementos, int posicion) {
		if ((posicion < 0) || (posicion >= elementos.length))
			throw new ArrayIndexOutOfBoundsException("A posición '" + posicion + "' está fora do rango do array, que ten " + elementos.length + " elementos");
		return elementos[posicion];
	}

}
