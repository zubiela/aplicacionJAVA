package fp.dam.ud4.p1;

import java.util.Scanner;

public class Exercicio1 {	
	
	/**
	 * Método principal da aplicación	
	 * @param args	Argumentos recibidos por consola
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		try {
			System.out.print("Introduce o numerador: ");
			float numerador = scanner.nextFloat();
			
			System.out.print("Introduce o denominador: ");
			float denominador = scanner.nextFloat();
			
			float resultado = dividir(numerador, denominador);
			System.out.println("O resultado da división é: " + resultado);
		}
		catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		catch (Exception e) {
			System.out.println("Houbo un erro: " + e.getMessage());
		}
		finally {
			scanner.close();
		}
	}

	/**
	 * Realiza a división de dous números
	 * 
	 * @param numerador		Numerador da división
	 * @param denominador	Denominador da división
	 * @return	resultado da división
	 */
	public static float dividir(float numerador, float denominador) {
		if (denominador == 0)
			throw new ArithmeticException("Non se permite a división por cero");
		return numerador/denominador;
	}

}
