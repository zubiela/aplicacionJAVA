package fp.dam.ud4.p1;

import java.util.Scanner;

/**
 * Clase do exercicio 1
 */
public class Exercicio1 {
	
	/**
	 * Método main principal que executa o exercicio
	 * 
	 * @param args Parámetros que se pasan por consola
	 */
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Introduce o numerador: ");
			int numerador = scanner.nextInt();

			System.out.print("Introduce o denominador: ");
			int denominador = scanner.nextInt();

			double resultado = realizarDivision(numerador, denominador);
			System.out.println("Resultado da división: " + resultado);

		} catch (ArithmeticException e) {
			System.out.println("Erro na operación aritmética: " + e.getMessage());

		} catch (Exception e) {
			System.out.println((e.getMessage() != null) ? e.getMessage() : "Erro xenérico");

		} finally {
			System.out.println("Programa rematado.");
			scanner.close();
		}
	}

	/**
	 * Método que realiza a división de dous números de xeito que propaga unha excepción controlada se
	 * hai un erro
	 * 
	 * @param numerador   numerador da división
	 * @param denominador denominador da división
	 * @return resultado da operación
	 * @throws ArithmeticException excepción propagada en caso de erro
	 */
	private static double realizarDivision(int numerador, int denominador)  {
		if (denominador == 0) {
			throw new ArithmeticException("Non se pode dividir por cero.");
		}
		return (double) numerador / denominador;
	}
}
