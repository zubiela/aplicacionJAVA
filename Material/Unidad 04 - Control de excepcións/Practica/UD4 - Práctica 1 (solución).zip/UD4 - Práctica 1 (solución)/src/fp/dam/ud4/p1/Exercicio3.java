package fp.dam.ud4.p1;

import java.util.Scanner;

public class Exercicio3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Cantidade de notas a introducir: ");
			int cantidadeNotas = scanner.nextInt();

			if (cantidadeNotas <= 0) {
				throw new IllegalArgumentException("A cantidade de notas debe ser un número positivo.");
			}

			double[] notas = new double[cantidadeNotas];
			for (int i = 0; i < cantidadeNotas; i++) {
				System.out.print("Introduce a nota #" + (i + 1) + ": ");
				notas[i] = scanner.nextDouble();

				if (notas[i] < 0 || notas[i] > 10) {
					throw new IllegalArgumentException("As notas deben estar no rango de 0 a 10.");
				}
			}

			double media = calcularMedia(notas);
			System.out.println("A media das notas é: " + media);

		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());

		} catch (Exception e) {
			System.out.println((e.getMessage() == null) ? "Erro xeral" : e.getMessage());

		} finally {
			System.out.println("Programa rematado.");
			scanner.close();
		}
	}

	private static double calcularMedia(double[] notas) {
		double suma = 0;
		for (double nota : notas) {
			suma += nota;
		}
		return suma / notas.length;
	}
}
