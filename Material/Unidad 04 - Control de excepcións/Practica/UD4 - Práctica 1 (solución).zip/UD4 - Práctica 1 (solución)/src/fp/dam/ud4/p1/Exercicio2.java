package fp.dam.ud4.p1;

import java.util.Scanner;

/**
 * Clase do exercicio 2
 */
public class Exercicio2 {

	/**
	 * Método main principal que executa o exercicio
	 * 
	 * @param args Parámetros que se pasan por consola
	 */
	public static void main(String[] args) {
		String[] elementos = { "Elemento 1", "Elemento 2", "Elemento 3", "Elemento 4", "Elemento 5" };

		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Introduce a posición do elemento a consultar: ");
			int posicion = scanner.nextInt();

			String elementoConsultado = consultarElemento(elementos, posicion);
			System.out.println("Elemento consultado: " + elementoConsultado);

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Índice non válido. Asegúrate de introducir unha posición válida.");

		} catch (Exception e) {
			System.out.println("Erro: " + e.getMessage());

		} finally {
			System.out.println("Programa rematado.");
			scanner.close();
		}
	}

	/**
	 * Método que consulta un elemento nun array e que en caso de que a posición indicada se atope fora
	 * dos límites, lance unha excepción contralada
	 * 
	 * @param elementos		array que contén os elementos
	 * @param posicion		posición a consultar dentro do array
	 * @return				elemento do array atopado
	 */
	private static String consultarElemento(String[] elementos, int posicion) {
		if (posicion < 0 || posicion >= elementos.length) {
			throw new ArrayIndexOutOfBoundsException("Índice fora dos límites do array.");
		}
		return elementos[posicion];
	}
}
