
/**
 * Clase de referencia para realizar a aplicación da práctica 2 da unidade 1  
 */
public class Unidade1P2Ex1 {

	public static void main(String[] args) {
		
		float altura = 23.56f;
		float base = 18.73f;				
		float area = (base * altura)/2;
		
		System.out.println("A área do triángulo é: " + area);		
	}
}
