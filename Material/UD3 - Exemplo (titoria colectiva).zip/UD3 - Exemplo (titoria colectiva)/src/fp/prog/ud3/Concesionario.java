package fp.prog.ud3;

import java.util.Arrays;

public class Concesionario {

	protected String nome;
	protected String enderezo;
	protected Automobil[] automobiles = new Automobil[100];

	/**
	 * @param nome
	 * @param enderezo
	 */
	public Concesionario(String nome, String enderezo) {
		this.nome = nome;
		this.enderezo = enderezo;
	}

	/**
	 * Engade un auto ao concesionario
	 * 
	 * @param  auto
	 * @return
	 */
	public boolean engadirAutomobil(Automobil auto) {
		for (int i = 0; i < automobiles.length; i++) {
			if (automobiles[i] == null) {
				automobiles[i] = auto;
				return true;
			}
		}
		return false;
	}

	/**
	 * Devolve o total de coches
	 * 
	 * @return
	 */
	public int totalCoches() {
		int total = 0;
		for (Automobil auto : automobiles) {
			total = (auto == null) ? total : total + 1;
		}
		return total;
	}

	/**
	 * Comprobar coches de baixa
	 * 
	 * @return
	 */
	public int obterCochesBaixa() {
		int cont = 0;
		for (int i = 0; i < automobiles.length; i++) {
			if ((automobiles[i] != null) && (!automobiles[i].isActivado())) {
				cont++;
			}
		}
		return cont;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEnderezo() {
		return enderezo;
	}

	public void setEnderezo(String enderezo) {
		this.enderezo = enderezo;
	}

	public Automobil[] getAutomobiles() {
		return automobiles;
	}

	@Override
	public String toString() {
		String datos = "\n > Concesionario [nome=" + nome + ", enderezo=" + enderezo + "]";
	    datos += "\n  - Automobiles:";
	    for (Automobil auto : this.automobiles) {
	    	if (auto != null)
	    		datos +="\n      " + auto.toString();
	    }
		datos +="\n  - Total de coches: " + totalCoches();
		return datos;
	}

}
