package fp.prog.ud3;

import java.util.Date;

public class Automobil {
	
	private static int automobilesTotais = 0;
	
	private String marca;
	private String modelo;
	private String matricula;
	private Date fechaMatricula;
	private boolean activado;
	 
	
	/**
	 * Constructor 
	 * 
	 * @param marca
	 * @param modelo
	 * @param matricula
	 * @param fechaMatricula
	 */
	public Automobil(String marca, String modelo, String matricula, Date fechaMatricula) {
		this.marca = marca;
		this.modelo = modelo;
		this.matricula = matricula;
		this.fechaMatricula = fechaMatricula;
		this.activado = true;
		Automobil.automobilesTotais++;
	}

	public String getMarca() {
		return this.marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Date getFechaMatricula() {
		return fechaMatricula;
	}

	public void setFechaMatricula(Date fechaMatricula) {
		this.fechaMatricula = fechaMatricula;
	}	
	
	public boolean isActivado() {
		return activado;
	}

	public void setActivado(boolean activado) {
		this.activado = activado;
	}

	public static int getAutomobilesTotales() {
		return automobilesTotais;
	}

	@Override
	public String toString() {
		return "Automobil [marca=" + marca + ", modelo=" + modelo + ", matricula=" + matricula + ", fechaMatricula=" + fechaMatricula + "]";
	}	
	
}
