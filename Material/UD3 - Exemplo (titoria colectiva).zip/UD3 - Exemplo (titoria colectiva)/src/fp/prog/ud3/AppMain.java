package fp.prog.ud3;

import java.util.Date;

public class AppMain {

	public static void main(String[] args) {
		Concesionario[] concesionarios = new Concesionario[5];
		
		concesionarios[0] = new Concesionario("Concesionario 1", "Rúa Nova, 24 - Compostela");
		Automobil auto1 = new Automobil("Peugeot", "3008", "9043G", new Date());
		concesionarios[0].engadirAutomobil(auto1);		
		concesionarios[0].engadirAutomobil(new Automobil("Toyota", "Rav4", "4367J", new Date()));
		concesionarios[0].engadirAutomobil(new Automobil("Peugeot", "3008", "9043G", new Date()));
		
		concesionarios[1] = new Concesionario("Concesionario 2", "Rúa do Sol, 14 - Vigo");		
		concesionarios[1].engadirAutomobil(new Automobil("Citroën", "C4", "2387K", new Date()));
		concesionarios[1].engadirAutomobil(new Automobil("Renault", "Megane", "3145L", new Date()));
		concesionarios[1].engadirAutomobil(new Automobil("Ford", "Focus", "4218M", new Date()));
		concesionarios[1].engadirAutomobil(new Automobil("Toyota", "Corolla", "5429N", new Date()));

		
		concesionarios[2] = new Concesionario("Concesionario 3", "Avda. das Mariñas, 45 - A Coruña");
		concesionarios[2].engadirAutomobil(new Automobil("Audi", "A4", "9673S", new Date()));
		concesionarios[2].engadirAutomobil(new Automobil("Kia", "Ceed", "0148T", new Date()));
		concesionarios[2].engadirAutomobil(new Automobil("Hyundai", "i30", "1269U", new Date()));
		concesionarios[2].engadirAutomobil(new Automobil("Mazda", "3", "2391V", new Date()));
		concesionarios[2].engadirAutomobil(new Automobil("Seat", "León", "3472W", new Date()));


		concesionarios[3] = new Concesionario("Concesionario 4", "Rúa Vella, 4 - Ourense");
		concesionarios[3].engadirAutomobil(new Automobil("Volkswagen", "Golf", "6310P", new Date()));
		concesionarios[3].engadirAutomobil(new Automobil("BMW", "Serie 3", "7341Q", new Date()));
		concesionarios[3].engadirAutomobil(new Automobil("Mercedes", "Clase C", "8562R", new Date()));
		concesionarios[3].engadirAutomobil(new Automobil("Nissan", "Qashqai", "4893X", new Date()));
		concesionarios[3].engadirAutomobil(new Automobil("Opel", "Astra", "5314Y", new Date()));
		
		Automobil auto18 = new Automobil("Skoda", "Octavia", "6723B", new Date());
		Automobil auto19 = new Automobil("Volvo", "XC40", "7854C", new Date());
		Automobil auto20 = new Automobil("Chevrolet", "Cruze", "8935D", new Date());
		Automobil auto21 = new Automobil("Subaru", "Impreza", "3496E", new Date());
		Automobil auto22 = new Automobil("Mitsubishi", "Outlander", "5687F", new Date());

		
		// Mostrar os concesionarios
		for (Concesionario concesionario :concesionarios) {
			if (concesionario != null)
				System.out.println(concesionario.toString());
		}
		
		System.out.println("\n\n > O número total de coches fabricados é: " + Automobil.getAutomobilesTotales());
		
	}

}
