package fp.prog.ud3.exem4;

/**
 * Clase Ex3Main: Clase principal do exemplo 4 que define o método main que se utiliza para executar o exemplo
 */
public class Ex4Main {

	/** 
	 * Constante da clase que define o número de usuarios que imos xerar, coas súas respectivas tarxetas, usados para
	 * probar as funcionalidades do sistema
	 */
	public static final int USERS = 3;

	/**
	 * Método principal que se utiliza para executar e probar o exemplo 4
	 * 
	 * @param args argumentos pasados por consola
	 */
	public static void main(String[] args) {
		User[] users = Ex4Data.generateUsers(USERS);
		Card[] cards = Ex4Data.generateCards(users);
		Boolean exitApp = false;

		while (!exitApp) {
			AppCtrl.showMainMenuUI();

			Integer option = AppCtrl.getReadData().nextInt();
			
			switch (option) {
			case 1:
				AppCtrl.showCardDataUI(cards);
				System.out.println("");
				break;
			case 2:
				AppCtrl.showCardBalanceUI(cards);
				System.out.println("");
				break;
			case 3:
				AppCtrl.showPayCard(cards);
				System.out.println("");
				break;
			case 4:
				exitApp = true;
			}
			AppCtrl.getReadData().nextLine(); // limpamos o buffer
		}
		AppCtrl.getReadData().close();
	}	
}
