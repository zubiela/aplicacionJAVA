/**
 * Este módulo contén un exemplo complexo no que se definen dúas clases Card e User que emulan o funcionamento dun sistema
 * de tarxetas de crédito, coa súa validación con número de tarxeta e PIN e un método para facer pagos.
 *
 * @since 1.0
 * @author Manuel Pacior Pérez
 * @version 1.0
 */
package fp.prog.ud3.exem4;