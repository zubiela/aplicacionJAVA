package fp.prog.ud3.exem2;

import java.util.Date;

/**
 * Clase Contact: Esta clase úsase para soportar os contactos dunha axenda de usuarios
 */
public class Contact {

	private String email; // Enderezo de correo electrónico
	private String name; // Nome
	private String surname; // Apelidos
	private Date birthDate; // Data de nacemento
	private String address; // Enderezo
	private String postalCode; // Código postal
	private String phone; // Número de teléfono


	/**
	 * Constructor de contacto
	 * 
	 * @param email email do contacto
	 * @param name nome do contacto
	 */
	public Contact(String email, String name) {
		this.email = email;
		this.name = name;
	}

	/**
	 * Obtén o email
	 * 
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Configura o email
	 * 
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Obtén o nome
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Configura o nome
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Obtén os apelidos
	 * 
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * Configura os apelidos
	 * 
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * Obtén a data de nacemento
	 * 
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Configura a data de nacemento
	 * 
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Obtén o enderezo
	 * 
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Configura o enderezo
	 * 
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Obtén o código postal
	 * 
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Configura o código postal
	 * 
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Obtén o número de teléfono
	 * 
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Configura o número de teléfono
	 * 
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Converte o obxecto a un String
	 * 
	 * @return cadea cos datos do obxecto
	 */
	@Override
	public String toString() {
		return "Contact [email=" + email + ", name=" + name + ", surname=" + surname + ", birthDate=" + birthDate + ", address=" + address
				+ ", postalCode=" + postalCode + ", phone=" + phone + "]";
	}
	
}
