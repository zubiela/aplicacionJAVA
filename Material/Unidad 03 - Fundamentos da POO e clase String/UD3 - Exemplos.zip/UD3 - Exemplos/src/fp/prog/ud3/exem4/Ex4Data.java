package fp.prog.ud3.exem4;

import java.util.Date;

import fp.prog.ud3.Util;

/**
 * Clase UtilData: Utilízase para definir todos os métodos para xerar datos para probar a nosa aplicación.
 */
public class Ex4Data {

	/**
	 * Clase estática que contén os arrays cos datos de proba de usuarios
	 */
	protected static final class UserData {
		public static String DIS[] = { "34256787J", "11233212A", "54678998Y", "34565432G", "78998765D", "65442345U",
				"45665478H", "33365877D" };
		public static String NAMES[] = { "Lois", "Alba", "Antón", "Xiana", "Fiz", "Carme", "Brais", "Lía" };
		public static String SURNAMES[] = { "Paz Andrade", "Souto Pérez", "Liaño Barcia", "Castiñeira Cal",
				"Lodeiro Pena", "Pena Albor", "Lamas Teo", "Carrión Lei" };

		public static Date BIRTH_DATES[] = { Util.getDate("23/02/1969"), Util.getDate("13/11/1979"),
				Util.getDate("23/07/1989"), Util.getDate("13/11/1979"), Util.getDate("13/11/1979"),
				Util.getDate("06/09/1964"), Util.getDate("09/09/1999"), Util.getDate("13/13/2003") };

		public static String ADDRESSES[] = { "Rúa nova 45, 1C", "Rúa vella 12, 3E", "Ponte de arriba 123, 1C",
				"Avda. Castelao 23, 3A", "Avda. Ferrol 33, 1E", "Costa Vella s/n, 3E", "Otero Pedrayo 33, 5C",
				"Rosalía de Castro 45, 2C" };
		public static String POSTAL_CODES[] = { "27658", "12543", "44312", "32412", "54101", "21002", "33171",
				"09321" };
		public static String PHONES[] = { "567654453", "668765234", "687112345", "627887654", "689123345", "698776654",
				"654432256", "677897098" };
	}

	/**
	 * Clase estática que contén os arrays cos datos de proba de tarxetas
	 */
	protected static final class CardData {
		
		public static String[] BANK_NAME = { "Banco Sabadell", "La Caixa", "ING", "N26",	"OpenBank", "BBVA", "Caixa Rural Galega", "Abanca" };
		public static String CARD_NUMBER[] = { "98234567/345", "18034267/142", "36084267/849", "25014269/145", "55534512/349", "89034233/241", "11184267/119", "81614261/245"};

		public static Double[] BALANCE = { 400d, 100d, 50d, 0d, 235d, 1200d, 2500d, 333d };

		public static Date[] EXPIRATION_DATE = { Util.getDate("23/02/2025"), Util.getDate("13/11/2022"),
				Util.getDate("23/07/2021"), Util.getDate("13/11/2019"), Util.getDate("13/11/2021"),
				Util.getDate("06/09/2034"), Util.getDate("09/09/2029"), Util.getDate("13/13/2033") };

		public static String PINS[] = { "1234", "1234", "1234", "1234", "1234", "1234", "1234", "1234" };
	}

	/**
	 * Método que xera o número de usuarios indicados por parámetro combinando para
	 * elo, de xeito aleatorio, os datos que temos definidos nos arrays cos modelos
	 * que se definen enriba.
	 * 
	 * @param numUsers número de usuarios que queremos xerar
	 * @return usuarios xerados
	 */
	public static User[] generateUsers(int numUsers) {
		User[] users = new User[numUsers];
		for (int i = 0; i < users.length; i++) {
			String di = UserData.DIS[Util.getIndexRandom(UserData.DIS.length)];
			String name = UserData.NAMES[Util.getIndexRandom(UserData.NAMES.length)];
			String surname = UserData.SURNAMES[Util.getIndexRandom(UserData.SURNAMES.length)];
			Date birthDate = UserData.BIRTH_DATES[Util.getIndexRandom(UserData.BIRTH_DATES.length)];
			String address = UserData.ADDRESSES[Util.getIndexRandom(UserData.ADDRESSES.length)];
			String postalCode = UserData.POSTAL_CODES[Util.getIndexRandom(UserData.POSTAL_CODES.length)];
			String phone = UserData.PHONES[Util.getIndexRandom(UserData.PHONES.length)];
			String email = name.toLowerCase() + "@email.com";
			users[i] = new User(di, name, surname, birthDate, address, postalCode, phone, email);
		}

		return users;
	}

	/**
	 * Método que xera unha tarxeta para cada un dos usuarios pasados por parámetros
	 * a través do array.
	 * 
	 * @param users usuarios para os que imos xerar as tarxetas
	 * @return tarxetas xeradas para cada usuario
	 */
	public static Card[] generateCards(User[] users) {
		Card[] cards = new Card[users.length];
		for (int i = 0; i < cards.length; i++) {

			String bankName = CardData.BANK_NAME[Util.getIndexRandom(CardData.BANK_NAME.length)];
			String cardNumber = CardData.CARD_NUMBER[Util.getIndexRandom(CardData.CARD_NUMBER.length)];
			Double balance = CardData.BALANCE[Util.getIndexRandom(CardData.BALANCE.length)];
			Date expirationDate = CardData.EXPIRATION_DATE[Util.getIndexRandom(CardData.EXPIRATION_DATE.length)];
			String pin = CardData.PINS[i]; // O pin asígnoo na mesma orde que está definido, porque facilita as probas 
			cards[i] = new Card(bankName, cardNumber, balance, expirationDate, pin, users[i]);					
		}
		return cards;
	}

}
