package fp.prog.ud3.exem2;

/**
 * Clase Ex2Main: Clase principal do exemplo 2 que define o método main que se utiliza para executar o exemplo
 */
public class Ex2Main {

	/**
	 * Método principal que executa o exemplo 2
	 * 
	 * @param args argumentos pasados por consola
	 */
	public static void main(String[] args) {		
		Contact contact1 = new Contact("Antón", "anton19876@gmail.com");
		
		Contact contact2 = contact1; // Declaramos contact2 e inicializámolo como contact1. Neste caso será o mesmo obxecto, xa
		// que ao declaralo deste xeito, contact2 apunta á mesma posición de memoria á que apunta contact1
		
		checkObjects(contact1, contact2);
		System.out.println("");
		System.out.println("Agoa imos aplicar un cambio sobre contact2, asignando un número de teléfono.");
		contact2.setPhone("666 777 888");
		
		System.out.println("Amosamos os datos de contact1: " + contact1.toString());
		
		System.out.println("Vemos que contact1 tamén ten o teléfono cambiado, porque ao declaralo imos aplicar un cambio sobre contact2.");

		// Nos seguintes exemplos debedes fixarvos como cambia o obxecto param1 ao chamar a func2, pero sin embargo
		// non o fai cando se invoca a func1 
		int param1 = 6;
		System.out.println("Imos a comprobar a función 'func1':");
		func1(param1);
		System.out.println(" - Param1: " + param1);
		
		System.out.println("Imos a comprobar a función 'func2':");
		func2(contact1);
		System.out.println(" - Contac1: " + contact1.toString());

	}
	
	/**
	 * Comproba se dous parámetros son o mesmo obxecto e se teñen o mesmo valor
	 * 
	 * @param c1 contacto 1
	 * @param c2 contacto 2
	 */
	public static void checkObjects(Contact c1, Contact c2) {
		System.out.println("");
		System.out.println("[COMPROBANDO OBXECTOS IDÉNTICOS]: ");
		if (c1 == c2) {
			System.out.println(" => Os dous son o mesmo obxecto");
		} else {
			System.out.println(" => Os dous son obxectos diferentes");
		}
		if (c1.equals(c2)) {
			System.out.println(" => Os obxectos teñen asignado o mesmo valor");
		} else {
			System.out.println(" => Os obxectos teñen asignados valores diferentes");
		}
		System.out.println("    - Variable 1 [Valor: '" + c1 + "', ID: " + java.lang.System.identityHashCode(c1) + "]");
		System.out.println("    - Variable 2 [Valor: '" + c2 + "', ID: " + java.lang.System.identityHashCode(c2) + "]");
	}	
	
	/**
	 * Exemplo de función con paso de parámetros primitivos. 
	 * <p>
	 * Cando se pasa un parámetro que representa unha variable primitiva, en realidade estamos pasando 
	 * o seu valor, así que os cambios que se fagan dentro da función non saen para fora, xa que dentro
	 * da función asígnase á variable indicada e o ámbito da mesma é a propia función
	 * </p>
	 * 
	 * @param param1 parámetro primitivo de tipo int
	 */
	public static void func1(int param1) {
		param1 = 45;		
	}

	/**
	 * Exemplo de función con paso de parámetros non primitivos. Neste caso pasamos un obxecto de Contact.
	 * 
	 * <p>
	 * Cando se pasa un parámetro que representa unha variable non primitiva (un obxecto), en realidade 
	 * estamos pasando a referencia á posición de memoria onde se atopa gardada esa variable. Polo tanto, 
	 * neste caso os trocos realizados que se fagan dentro da función saen para fora, pois aínda que dentro
	 * da función asígnase a unha variable e o seu ámbito é a propia función. En realidade aínda que é unha 
	 * nova variable, os cambios fanse sobre as mesmas posicións de memoria que representa o obxecto pasado
	 * como parámetro da función.
	 * </p>
	 * 
	 * @param param1 parámetro complexo, obxecto de tipo Contact
	 */
	public static void func2(Contact param1) {
		param1.setName("Novo nome");
	}

}
