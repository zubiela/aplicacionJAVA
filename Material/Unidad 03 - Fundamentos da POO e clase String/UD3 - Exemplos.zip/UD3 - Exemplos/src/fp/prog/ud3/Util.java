package fp.prog.ud3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase Util: Clase xenérica, que se utiliza para definir métodos e recursos xerais a todos os exemplos.
 */
public class Util {

	/**
	 * Estou redefinindo o construtor por defecto para que non se poidan xerar obxectos deste tipo
	 * A súa finalidade é ter unha serie de métodos e recursos estáticos (da clase) que se poidan
	 * utilizar para transformación e formatado de datos.
	 * 
	 */
	protected Util() {
		
	}
	
	/**
	 * Obtén a data a partires do seu valor como cadea co seguinte formato: "dd/MM/yyyy"
	 * 
	 * @param strDate data en formato "dd/MM/yyyy"
	 * @return data en formato 'Date'
	 */
	public static Date getDate(String strDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
			return dateFormat.parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Obtén a data a partires do seu valor como cadea co formato indicado por parámetro
	 * 
	 * @param date 		data a transformar
	 * @param pattern	patrón ou modelo que queremos aplicar á saída de data
	 * @return 			Devolve unha cadea que contén a data no formato indicado
	 */
	public static String format(Date date, String pattern) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		return dateFormat.format(date);
	}
	
	/**
	 * Obtén a data como cadea no seguinte formato "dd/MM/yyyy" a partires do seu valor como tipo Date 
	 * 
	 * @param date 		data a transformar
	 * @return 			Devolve unha cadea que contén a data no formato indicado
	 */
	public static String format(Date date) {
		return Util.format(date, "dd/MM/yyyy");
	}

	/**
	 * Xera un número aleatorio entre 0 e index
	 * 
	 * @param index o número xerado debe estar comprendido entre 0 e index (non incluído)
	 * @return número aleatorio entre [0, index)
	 */
	public static int getIndexRandom(int index) {
		return (int) Math.floor(Math.random() * index);
	}

}
