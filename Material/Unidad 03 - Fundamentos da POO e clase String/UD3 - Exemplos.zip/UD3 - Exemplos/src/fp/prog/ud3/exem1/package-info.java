/**
 * Este módulo contén exemplos básicos do uso de String e como se comparan correctamente obxectos
 *
 * @since 1.0
 * @author Manuel Pacior Pérez
 * @version 1.0
 */
package fp.prog.ud3.exem1;