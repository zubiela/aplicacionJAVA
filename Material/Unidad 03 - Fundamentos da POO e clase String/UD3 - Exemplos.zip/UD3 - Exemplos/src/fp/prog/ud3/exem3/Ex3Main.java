package fp.prog.ud3.exem3;

import fp.prog.ud3.Util;
import fp.prog.ud3.exem3.Vehicle.VehicleType;

/**
 * Clase Ex2Main: Clase principal do exemplo 2 que define o método main que se utiliza para executar o exemplo
 */
public class Ex3Main {

	/**
	 * Método principal que executa o exemplo 3
	 * 
	 * @param args argumentos pasados por consola
	 */
	public static void main(String[] args) {		
		
		Vehicle[] vehicles = new Vehicle[10];
		
		// Creamos varios vehículos usando o construtor definido para ese cometido
		vehicles[0] = new Vehicle("4400GFP", "Hyundai Tucson", Util.getDate("23/02/2018"), VehicleType.CAR);
		vehicles[1] = new Vehicle("2367IFW", "Yamaha MT-09", Util.getDate("13/08/2022"), VehicleType.MOTORCYCLE);
		System.out.println(" Os datos do vehículo engadido son os seguintes");
		System.out.println(vehicles[1].toString());
		
		/**
		 * Como no constructor temos indicado que cando se crea un novo vehículo se incremente a variable estática
		 * da clase "totalVehicles", despois podemos consultala desde a propia clase e terá ese valor actualizado
		 * Debemos ver os atributos e métodos estáticos dunha clase como elementos compartidos, isto é, ao contrario 
		 * do que sucede cos atributos e métodos non estáticos, que se crean por cada obxecto e pertencen a este,
		 * os estáticos so se declaran unha vez e son compartidos por todos os obxectos.
		 */
		vehicles[2] = new Vehicle("7811MNQ", "Volvo 7900", Util.getDate("10/06/2023"), VehicleType.BUS);
		vehicles[3] = new Vehicle("4400GFP", "Hyundai Tucson", Util.getDate("23/02/2018"), VehicleType.CAR);
		System.out.println(" Déronse de alta no sistema un total de " + Vehicle.getTotalVehicles() + " vehículos");
	}	

}
