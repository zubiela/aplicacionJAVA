/**
 * Este módulo contén un exemplo de definición dunha clase que contén un atributo estático, e explícase con exemplos o seu funcionamento.
 *
 * @since 1.0
 * @author Manuel Pacior Pérez
 * @version 1.0
 */
package fp.prog.ud3.exem3;