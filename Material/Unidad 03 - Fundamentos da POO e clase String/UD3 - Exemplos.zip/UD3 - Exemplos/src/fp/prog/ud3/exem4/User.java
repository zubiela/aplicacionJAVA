package fp.prog.ud3.exem4;

import java.util.Date;

/**
 * Clase User: Esta clase representa aos usuarios do sistema
 */
public class User {

	private String di; // Documento de identidade
	private String name; // Nome
	private String surname; // Apelidos
	private Date birthDate; // Data de nacemento
	private String address; // Enderezo
	private String postalCode; // Código postal
	private String phone; // Número de teléfono
	private String email; // Enderezo de correo electrónico

	/**
	 * /** Constructor da clase: Método para instanciar obxectos de tipo usuario. Asignamos a cada
	 * atributo da clase (notación con this. ) cada parámetro equivalente do método. Fíxese que malia
	 * que chamei do mesmo xeito aos atributos, aínda que non ten porque ser así.
	 * 
	 * @param di Documento de identidade
	 * @param name Nome do usuario
	 * @param surname Apelidos do usuario
	 * @param birthDate Data de nacemento
	 * @param address Enderezo do usuario
	 * @param postalCode Código postal
	 * @param phone Número de teléfono do usuario
	 * @param email Correo electrónico do usuario
	 */
	public User(String di, String name, String surname, Date birthDate, String address, String postalCode, String phone, String email) {
		super();
		this.di = di;
		this.name = name;
		this.surname = surname;
		this.birthDate = birthDate;
		this.address = address;
		this.postalCode = postalCode;
		this.phone = phone;
		this.email = email;
	}

	/**
	 * Obtén o documento de identidade
	 * 
	 * @return the di
	 */
	public String getDi() {
		return di;
	}

	/**
	 * Configura o documento de identidade
	 * 
	 * @param di the di to set
	 */
	public void setDi(String di) {
		this.di = di;
	}

	/**
	 * Obtén o nome
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Configura o nome de usuario
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Obtén os apelidos
	 * 
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * Configura os apelidos
	 * 
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * Obtén a data de nacemento
	 * 
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Configura a data de nacemento
	 * 
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Obtén o enderezo
	 * 
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Configura o enderezo
	 * 
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Obtén o código postal
	 * 
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Configura o código postal
	 * 
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Obtén o teléfono
	 * 
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Configura o número de teléfono
	 * 
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Obtén o email
	 * 
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Configura o email
	 * 
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return name + " " + surname + ", con DI" + di + "]";
	}

}
