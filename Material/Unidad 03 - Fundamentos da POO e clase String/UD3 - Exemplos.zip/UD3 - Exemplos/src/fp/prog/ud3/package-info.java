/**
 * Este módulo contén os exemplos de código desta unidade 3, para que 
 * sirvan de guía na unidade.
 *
 * @since 1.0
 * @author Manuel Pacior Pérez
 * @version 1.0
 */
package fp.prog.ud3;