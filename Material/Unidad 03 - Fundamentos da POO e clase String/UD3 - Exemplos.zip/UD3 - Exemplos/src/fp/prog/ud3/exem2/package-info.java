/**
 * Este módulo contén exemplos de definición de métodos estáticos e como se pasan os parámetros, explicando a diferenza 
 * de comportamento cando se pasa como parámetro un dato primitivo ou un obxecto.
 *
 * @since 1.0
 * @author Manuel Pacior Pérez
 * @version 1.0
 */
package fp.prog.ud3.exem2;