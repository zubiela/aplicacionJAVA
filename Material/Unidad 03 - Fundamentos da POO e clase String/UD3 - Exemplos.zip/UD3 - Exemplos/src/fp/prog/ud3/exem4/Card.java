package fp.prog.ud3.exem4;

import java.util.Date;

/**
 * Clase Card: Esta clase representa ás tarxetas bancarias dos usuarios do sistema
 */
public class Card {

	private String bankName;
	private String cardNumber;
	private Double balance;
	private Date expirationDate;
	private String pin;

	private Boolean enabled;
	private User client;

	/**
	 *  Constructor da clase: Método para instanciar obxectos de tipo tarxeta.
	 *  Asignamos a cada atributo da clase (notación con this. ) cada parámetro equivalente do método.
	 *  Fíxese que malia que chamei do mesmo xeito aos atributos, aínda que non ten porque ser así.
	 *
	 * @param bankName 			nome do banco
	 * @param cardNumber 		número da tarxeta
	 * @param balance 			saldo da tarxeta
	 * @param expirationDate	data de caducidade
	 * @param pin				pin da tarxeta
	 * @param client			propietario (cliente) da tarxeta
	 */
	public Card(String bankName, String cardNumber, Double balance, Date expirationDate, String pin, User client) {
		this.bankName = bankName;
		this.cardNumber = cardNumber; 
		this.balance = balance; // Saldo inicial da tarxeta
		this.expirationDate = expirationDate;
		this.pin = pin;
		this.enabled = true; // Imos estimar que cando se crea unha tarxeta, está activa por defecto.
		this.client = client;
	}

	/**
	 * Método que comproba se a tarxeta está activa
	 * 
	 * @return se está activo ou non
	 */
	public boolean isActive() {
		return (enabled && expirationDate.after(new Date()));
	}
	
	/**
	 * Método que realiza un pago, que se realizará en función do estado da tarxeta
	 * (que se atope) activada, e que haxa saldo suficiente. En caso de que nos
	 * fagan unha devolución dun pago non reclamado, usarase este método e pasando a
	 * cantidade en negativo (cancélase o movemento previo), e deste xeito suma no
	 * balance total.
	 * 
	 * @param cardNumber número da tarxeta
	 * @param pin        pin da tarxeta
	 * 
	 * @return se a operación se realizou correctamente ou non
	 */
	public  boolean checkCardSecurity(String cardNumber, String pin) {
		if (isActive() && (this.cardNumber.equals(cardNumber)) && (this.pin.equals(pin)))
			return true;
		return false;
	}		

	/**
	 * Método que realiza un pago, que se realizará en función do estado da tarxeta
	 * (que se atope) activada, e que haxa saldo suficiente. En caso de que nos
	 * fagan unha devolución dun pago non reclamado, usarase este método e pasando a
	 * cantidade en negativo (cancélase o movemento previo), e deste xeito suma no
	 * balance total.
	 * 
	 * @param amount     cantidade do pago
	 * @return se a operación se realizou correctamente ou non
	 */
	public boolean pay(Double amount) {
		if (!isActive() || !checkCardSecurity(cardNumber,pin) || (balance < amount))
			return false;
		this.balance = this.balance - amount;
		return true;
	}


	/**
	 * Busca dentro dun array de tarxetas polo número de tarxeta
	 * 
	 * @param cards tarxetas
	 * @param cardNumber número de tarxetas
	 * @return tarxeta atopada ou null
	 */
	public static Card getCard(Card[] cards, String cardNumber) {
		for (Card card : cards) {
			if (card.getCardNumber().equals(cardNumber))
				return card;			
		}
		return null;
	}	
	
	/**
	 * Activa a tarxeta
	 */
	public void enable() {
		this.enabled = true;
	}

	/**
	 * Desactiva a tarxeta
	 */
	public void disable() {
		this.enabled = false;
	}

	/**
	 * Obtén o nome do banco da tarxeta
	 * 
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * Configura o nome do banco da tarxeta
	 * 
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Obtén o saldo da tarxeta
	 * 
	 * @return the balance
	 */
	public Double getBalance() {
		return balance;
	}

	/**
	 * Obtén a data de caducidade da tarxeta
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * Configura a data de caducidade da tarxeta
	 * 
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * Configura o PIN da tarxeta
	 * 
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}

	/**
	 * Obtén o usuario ou cliente da tarxeta
	 * 
	 * @return the client
	 */
	public User getClient() {
		return client;
	}

	/**
	 * Configura o cliente ou usuario da tarxeta
	 * 
	 * @param client the client to set
	 */
	public void setClient(User client) {
		this.client = client;
	}

	/**
	 * Obtén o número da tarxeta
	 * 
	 * @return the cardNumber
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * Configura o número da tarxeta
	 * 
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	@Override
	public String toString() {
		String text = "[Datos da tarxeta cos datos] \n - Cliente: " + client.toString() + " \n - Banco: " + bankName + " \n - Número: '" + cardNumber + "' \n - Saldo de '" + balance
				+ "'€ \n - Caduca: '" + expirationDate + "' \n - Estado: ";
		text = text + (isActive() ? "Está activa" : "Non está activa");
		
		return text;
	}
	
}
