package fp.prog.ud3.exem4;

import java.util.Scanner;

/**
 * Clase AppCtrl (Application Controller)
 * Nesta clase definimos todos os métodos necesarios para interactuar co usuario e coas clases de datos.
 * Basicamente contén definida a lóxica principal do funcionamento da aplicación. * 
 */
public class AppCtrl {

	/**
	 * Número máximo de intentos cando se insire o PIN na tarxeta
	 */
	public static final int PIN_ATTEMPTS = 4;

	private static Scanner readData = new Scanner(System.in);
	
	/**
	 * Declaramos como privado o constructor, deste xeito anulámolo pois non poderá usarse fora do ámbito
	 * da definición da propia clase. Facémolo así, xa que pola natureza desta clase, non é preciso crear
	 * obxectos ou instancias da clase, xa que so ten declarados métodos estáticos (da clase e non do
	 * obxecto) 
	 */
	private AppCtrl() {
		
	}
	
	/**
	 * Mostra o menú principal da aplicación
	 */
	public static void showMainMenuUI() {
		System.out.println("[MENÚ PRINCIPAL]");
		System.out.println("  1. Consultar tarxetas do sistema");
		System.out.println("  2. Consultar saldo da tarxeta");
		System.out.println("  3. Realizar pago con tarxeta");
		System.out.println("  4. Saír");
		System.out.println("");
		System.out.print(" Seleccione a opción a realizar: ");
	}

	/**
	 * Mostra a información dunha tarxeta seleccionada dentro dun array de tarxetas
	 * 
	 * @param cards array de tarxetas a mostrar
	 */
	public static void showCardDataUI(Card[] cards) {
		System.out.println("");
		System.out.println("  1. Consultar datos da tarxeta");
		System.out.print(" Elixa a tarxeta que quere consultar [0, " + (cards.length-1) + "]: ");
		Integer option = readData.nextInt();
		if (option >= 0)
			System.out.println(cards[option].toString());
		else
			System.out.println("A tarxeta seleccionada non é válida");
	}
	
	/**
	 * Método que solicita ao usuario un número de tarxeta e un pin, e valida que sexan
	 * correctos e devolve o resultado da operación:
	 * 	 - O número de tarxeta debe existir
	 *   - O pin indicado debe corresponderse co asignado á tarxeta
	 * 
	 * @param cards tarxetas do sistema
	 * 
	 * @return Tarxeta seleccionada ou null en caso contrario
	 */
	public static Card getCheckedCardUI(Card[] cards) {
		System.out.println("");
		System.out.print("Insire o nº de tarxeta: ");
		String cardNumber = readData.next();
		Card card = Card.getCard(cards, cardNumber);
		if (card == null) {
			System.out.println("O número da tarxeta indicada non existe no sistema.");
			return null;
		}
		int i = PIN_ATTEMPTS;
		do {
			System.out.print("Insire o PIN: ");		
			String carPin = readData.next();
			if (card.checkCardSecurity(cardNumber, carPin)) {
				return card;
			}
			else {
				System.out.println("O pin indicado non é correcto, volva a intentalo de novo");
				System.out.println("Quedan " + (i-1) + "/"  + PIN_ATTEMPTS + " intentos"); 
			}
			i--;
		}
		while (i > 0);
		
		// Se finaliza o máximo de intentos, entón devolve falso
		return null;
	}

	/**
	 * Mostra a información do balance seleccionando unha tarxeta entre as indicadas
	 * 
	 * @param cards tarxetas do sistema
	 */
	public static void showCardBalanceUI(Card[] cards) {
		Card card = AppCtrl.getCheckedCardUI(cards);
		if (card != null) {
			System.out.println("[ BALANCE DA TARXETA: " + card.getCardNumber() + "]");
			System.out.println("  - Saldo: " + card.getBalance() + " €");
		}
	}

	/**
	 * Mostra a información do balance seleccionando unha tarxeta entre as indicadas
	 * 
	 * @param cards tarxetas do sistema
	 */
	public static void showPayCard(Card[] cards) {
		Card card = AppCtrl.getCheckedCardUI(cards);
		if (card != null) {
			System.out.println("[ REALIZAR PAGO DA TARXETA: " + card.getCardNumber() + "]");
			System.out.print("  - Cantidade do pago: ");
			Double amount = readData.nextDouble();
			card.pay(amount);
			System.out.println(" [OK] Operación realizada con éxito. Saldo final: " + card.getBalance() + " €");
		}
	}

	/**
	 * Obtén o lector de datos, que é un obxecto de tipo Scanner
	 * 
	 * @return the readData obxecto de tipo Scanner
	 */
	public static Scanner getReadData() {
		return readData;
	}	
	

}
