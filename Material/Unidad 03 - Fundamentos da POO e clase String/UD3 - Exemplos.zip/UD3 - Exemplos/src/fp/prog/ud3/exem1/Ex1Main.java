package fp.prog.ud3.exem1;

/**
 * Clase Ex1Main: Clase principal do exemplo 1 que define o método main que se utiliza para executar o exemplo
 */
public class Ex1Main {

	/**
	 * Método principal que executa o exemplo 1
	 * 
	 * @param args argumentos pasados por consola
	 */
	public static void main(String[] args) {

		// Todos os obxectos dunha clase en Java instáncianse mediante o operador 'new'
		String text1 = new String(); // Creamos unha instancia (obxecto) da clase String
		text1 = ""; // Realmente non cambia o valor, porque new String() inicializa coa cadea
					// baleira
		text1 = new String("Ola!"); // O constructor da clase tamén permite pasar o parámetro que queremos
											// asignar
		String text2 = new String("Ola!"); // O constructor da clase tamén permite pasar o parámetro que queremos
													// asignar
		// Para comparar que dous obxectos teñen os mesmos datos usamos sempre o método equals
		checkObjects(text1, text2);

		// Neste caso si van ser o mesmo obxecto, xa que o obxecto text4 apunta a text3
		// (inicialízase apuntando a ese obxecto)
		String text3 = text2;
		checkObjects(text2, text3);
	}

	/**
	 * Comproba se dous parámetros son o mesmo obxecto e se teñen o mesmo valor
	 * 
	 * @param text1 obxecto de texto 1
	 * @param text2 obxecto de texto 2
	 */
	public static void checkObjects(String text1, String text2) {
		System.out.println("");
		System.out.println("[COMPROBANDO OBXECTOS IDÉNTICOS]: ");
		if (text1 == text2) {
			System.out.println(" => Os dous son o mesmo obxecto");
		} else {
			System.out.println(" => Os dous son obxectos diferentes");
		}
		if (text1.equals(text2)) {
			System.out.println(" => Os obxectos teñen asignado o mesmo valor");
		} else {
			System.out.println(" => Os obxectos teñen asignados valores diferentes");
		}
		System.out.println("    - Variable 1 [Valor: '" + text1 + "', ID: " + java.lang.System.identityHashCode(text1) + "]");
		System.out.println("    - Variable 2 [Valor: '" + text2 + "', ID: " + java.lang.System.identityHashCode(text2) + "]");
	}	
}
