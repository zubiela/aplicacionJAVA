package fp.prog.ud3.exem3;

import java.util.Date;

/**
 * Clase Vehicle: Esta clase representa un vehículo dunha axenda de usuarios nun sistema
 */
public class Vehicle {

	private static int totalVehicles = 0; // Aquí gardaremos a cantidade total de vehículos do sistema. Trátase dunha
											// variable da clase que é compartida por todos os obxectos da mesma.

	/**
	 * Tipo de dato enumerado, que permite representar valores discretos
	 */
	public enum VehicleType {
		/**
		 * Coche 
		 */
		CAR,
		/**
		 * Motocicleta
		 */
		MOTORCYCLE,
		/**
		 * Camión
		 */
		TRUCK,
		/** 
		 * Autobús
		 */
		BUS,
		/**
		 * Outro vehículo
		 */
		OTHER
	}

	private String code; // Matrícula do vehículo
	private String model; // Modelo do coche
	private Date date; // Data de fabricación
	private VehicleType type; // Tipo de vehículo

	/**
	 * Constructor da clase Vehicle
	 * 
	 * @param code  matrícula do vehículo
	 * @param model modelo do vehículo
	 * @param date  data de fabricación do vehículo
	 * @param type  tipo de vehículo
	 */
	public Vehicle(String code, String model, Date date, VehicleType type) {
		this.code = code;
		this.model = model;
		this.date = date;
		this.type = type;
		totalVehicles++;
	}

	/**
	 * Obtén a matrícula do vehículo
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Configura a matrícula do vehículo
	 * 
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Obtén o modelo do vehículo
	 * 
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * Configura o modelo do vehículo
	 * 
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * Obtén a data de fabricación do vehículo
	 * 
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Configura a data de fabricación do vehículo
	 * 
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Obtén o tipo de vehículo
	 * 
	 * @return the type
	 */
	public VehicleType getType() {
		return type;
	}

	/**
	 * Configura o tipo de vehículo
	 * 
	 * @param type the type to set
	 */
	public void setType(VehicleType type) {
		this.type = type;
	}

	/**
	 * Obtén o número total de vehículos
	 * 
	 * @return the totalVehicles
	 */
	public static int getTotalVehicles() {
		return totalVehicles;
	}

	/**
	 * Converte o obxecto a un String
	 * 
	 * @return cadea cos datos do obxecto
	 */
	@Override
	public String toString() {
		return " Datos do vehículo { \n  - Matrícula: " + code + ", \n  - Modelo: " + model + ", \n  - Data de fabricación: " + date
				+ ", \n  - Tipo: " + type + "\n }";
	}

}
